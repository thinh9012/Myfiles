﻿using log4net;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace ParseDataGinApp
{
    public partial class Form1 : Form
    {
        private static readonly ILog LOG = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private string folderPath = string.Empty;
        public Form1()
        {
            InitializeComponent();
            //LOG.Info("Hello logging world 1!");
        }

        private void btnDataPath_Click(object sender, System.EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                folderPath = fbd.SelectedPath;
            }

            // Setting textBox
            this.txtDataPath.Text = folderPath;
            this.txtSavePath.Text = folderPath;
        }

        private void btnCancel_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }

        private void btnParse_Click(object sender, System.EventArgs e)
        {
            Dictionary<string, object> dicResult = new Dictionary<string, object>();
        }

        private void getAllData(Dictionary<string, object> dicResult, string folderPath)
        {
            string folderName = Path.GetDirectoryName(folderPath);
            dicResult.Add(folderName, string.Empty);

            string[] folders = Directory.GetDirectories(folderPath);
            if(folders != null)
            {

            }

            DirectoryInfo folderInfo = new DirectoryInfo(folderPath);
            FileInfo[] files = folderInfo.GetFiles();
            string str = string.Empty;
            foreach (FileInfo file in files)
            {
                str = str + ", " + file.Name;
            }
        }

        private void getAllFileInFolder(string folderPath)
        {

        }
    }
}
