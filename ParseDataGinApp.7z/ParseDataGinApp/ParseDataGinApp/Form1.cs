﻿using log4net;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace ParseDataGinApp
{
    public partial class Form1 : Form
    {
        private static readonly ILog LOG = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private string folderPath = string.Empty;
        public Form1()
        {
            InitializeComponent();
            //LOG.Info("Hello logging world 1!");
        }

        private void btnDataPath_Click(object sender, System.EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                folderPath = fbd.SelectedPath;
            }

            // Setting textBox
            this.txtDataPath.Text = folderPath;
            this.txtSavePath.Text = folderPath;
        }

        private void btnCancel_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }

        private void btnSave_Click(object sender, System.EventArgs e)
        {
            Dictionary<string, object> dicResult = new Dictionary<string, object>();
            dicResult = getAllData(dicResult, folderPath);

            // Save data
            string test = string.Empty;
        }

        private Dictionary<string, object> getAllData(Dictionary<string, object> dicResult, string folderPath)
        {
            List<object> lstItems = new List<object>();
            string[] folders = Directory.GetDirectories(folderPath);
            if(folders != null)
            {
                List<Dictionary<string, object>> lstSubFolder = new List<Dictionary<string, object>>();
                foreach(string folder in folders)
                {
                    lstItems.Add(getAllData(new Dictionary<string, object>(), folder));
                }
            }

            DirectoryInfo folderInfo = new DirectoryInfo(folderPath);
            FileInfo[] files = folderInfo.GetFiles();
            string str = string.Empty;
            foreach (FileInfo file in files)
            {
                lstItems.Add(file.Name);
            }

            string folderName = Path.GetFileName(folderPath);
            dicResult.Add(folderName, lstItems);
            return dicResult;
        }
    }
}
