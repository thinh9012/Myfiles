﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClearFile
{
    /// <summary>
    /// Clear app process
    /// </summary>
    public partial class mainForm : Form
    {
        /// <summary> EXTENSION </summary>
        private const string EXTENSION = ".grod";

        /// <summary>
        /// Initialize
        /// </summary>
        public mainForm()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        /// <summary>
        /// Choose folder
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnChooseFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            DialogResult result = fbd.ShowDialog();
            if(DialogResult.OK.Equals(result))
            {
                txtPath.Text = fbd.SelectedPath;
            }
        }

        /// <summary>
        /// Exit app
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// Clear process
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                // Check folder existed
                if (!Directory.Exists(txtPath.Text))
                {
                    MessageBox.Show("Folder not exist!!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Process
                processClear(txtPath.Text);

                // Success report
                MessageBox.Show("Successfully!!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// processClear
        /// </summary>
        /// <param name="targetPath"></param>
        private void processClear(string targetPath)
        {
            // Sub folders
            string[] folders = Directory.GetDirectories(targetPath);
            folders.ToList().ForEach(f => processClear(f));

            // Files
            string[] files = Directory.GetFiles(targetPath);
            foreach(string file in files)
            {
                // Check extension
                if(!EXTENSION.Equals(Path.GetExtension(file).ToLower())) continue;

                // Check existed file retore
                if(files.Contains(file.Replace(EXTENSION, string.Empty)))
                {
                    File.Delete(file);
                }
            }
        }
    }
}
