﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClearFile
{
    /// <summary>
    /// Clear app process
    /// </summary>
    public partial class mainForm : Form
    {
        /// <summary> EXTENSION </summary>
        private const string EXTENSION = ".grod";

        /// <summary>
        /// Initialize
        /// </summary>
        public mainForm()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        /// <summary>
        /// Choose folder
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSelectFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            DialogResult result = fbd.ShowDialog();
            if (DialogResult.OK.Equals(result))
            {
                lstViewMain.Items.Add(fbd.SelectedPath);
            }
        }

        /// <summary>
        /// Exit app
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// Execute app
        /// Delete all file duplicate in list folder (.GROD extension)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExecute_Click(object sender, EventArgs e)
        {
            try
            {
                long totalFile = 0;
                List<string> lstTarget = getSelectFolder();
                foreach (string target in lstTarget)
                {
                    // Execute
                    executeClear(target, ref totalFile);
                }

                // Success report
                MessageBox.Show(string.Format("Execute total file: {0}", totalFile), "Successfully!!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// getSelectFolder
        /// </summary>
        /// <returns></returns>
        private List<string> getSelectFolder()
        {
            List<string> lstResult = new List<string>();

            List<string> lstItem = lstViewMain.Items.Cast<ListViewItem>().Select(item => item.Text).Distinct().ToList();
            foreach (string item in lstItem)
            {
                // Check folder existed
                if (!Directory.Exists(item))
                    continue;

                // Check selected parent folder
                if (!checkSelectFolder(lstItem, item))
                    continue;

                lstResult.Add(item);
            }

            return lstResult;
        }

        /// <summary>
        /// Check selected parent folder
        /// </summary>
        /// <param name="lstItem"></param>
        /// <param name="itemCheck"></param>
        /// <returns></returns>
        private bool checkSelectFolder(List<string> lstItem, string itemCheck)
        {
            foreach (string item in lstItem)
            {
                if (itemCheck.Equals(item))
                    continue;

                if (itemCheck.StartsWith(item))
                    return false;
            }

            return true;
        }

        /// <summary>
        /// executeClear
        /// </summary>
        /// <param name="targetPath"></param>
        /// <param name="totalFile"></param>
        private void executeClear(string targetPath, ref long totalFile)
        {
            // Execute sub folders
            string[] folders = Directory.GetDirectories(targetPath);
            foreach (string folder in folders)
            {
                try
                {
                    executeClear(folder, ref totalFile);
                }
                catch(Exception ex)
                {
                    System.Console.WriteLine(ex.Message);
                }
            }

            // Files
            string[] files = Directory.GetFiles(targetPath);
            foreach (string file in files)
            {
                // Check extension
                if (!EXTENSION.Equals(Path.GetExtension(file).ToLower())) continue;

                // Check existed file retore
                if (files.Contains(file.Replace(EXTENSION, string.Empty)))
                {
                    totalFile++;
                    File.Delete(file);
                }
            }
        }

        /// <summary>
        /// Unselect folder
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUnselectFolder_Click(object sender, EventArgs e)
        {
            var items = lstViewMain.SelectedItems;
            foreach (var item in items)
            {
                lstViewMain.Items.Remove((ListViewItem)item);
            }
        }

        /// <summary>
        /// Clear all select folder
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClearAllFolder_Click(object sender, EventArgs e)
        {
            lstViewMain.Clear();
        }
    }
}
