﻿namespace ClearFile
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpMain = new System.Windows.Forms.GroupBox();
            this.btnUnselectFolder = new System.Windows.Forms.Button();
            this.lstViewMain = new System.Windows.Forms.ListView();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnExecute = new System.Windows.Forms.Button();
            this.btnSelectFolder = new System.Windows.Forms.Button();
            this.btnClearAllFolder = new System.Windows.Forms.Button();
            this.grpMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpMain
            // 
            this.grpMain.Controls.Add(this.btnClearAllFolder);
            this.grpMain.Controls.Add(this.btnUnselectFolder);
            this.grpMain.Controls.Add(this.lstViewMain);
            this.grpMain.Controls.Add(this.btnExit);
            this.grpMain.Controls.Add(this.btnExecute);
            this.grpMain.Controls.Add(this.btnSelectFolder);
            this.grpMain.Location = new System.Drawing.Point(12, 12);
            this.grpMain.Name = "grpMain";
            this.grpMain.Size = new System.Drawing.Size(580, 337);
            this.grpMain.TabIndex = 0;
            this.grpMain.TabStop = false;
            this.grpMain.Text = "Delete all file duplicate in list folder (.GROD extension)";
            // 
            // btnUnselectFolder
            // 
            this.btnUnselectFolder.Location = new System.Drawing.Point(102, 301);
            this.btnUnselectFolder.Name = "btnUnselectFolder";
            this.btnUnselectFolder.Size = new System.Drawing.Size(99, 23);
            this.btnUnselectFolder.TabIndex = 5;
            this.btnUnselectFolder.Text = "Unselect Folder";
            this.btnUnselectFolder.UseVisualStyleBackColor = true;
            this.btnUnselectFolder.Click += new System.EventHandler(this.btnUnselectFolder_Click);
            // 
            // lstViewMain
            // 
            this.lstViewMain.Location = new System.Drawing.Point(6, 19);
            this.lstViewMain.Name = "lstViewMain";
            this.lstViewMain.Size = new System.Drawing.Size(568, 276);
            this.lstViewMain.TabIndex = 4;
            this.lstViewMain.UseCompatibleStateImageBehavior = false;
            this.lstViewMain.View = System.Windows.Forms.View.List;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(499, 301);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnExecute
            // 
            this.btnExecute.Location = new System.Drawing.Point(418, 301);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(75, 23);
            this.btnExecute.TabIndex = 2;
            this.btnExecute.Text = "Execute";
            this.btnExecute.UseVisualStyleBackColor = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // btnSelectFolder
            // 
            this.btnSelectFolder.Location = new System.Drawing.Point(6, 301);
            this.btnSelectFolder.Name = "btnSelectFolder";
            this.btnSelectFolder.Size = new System.Drawing.Size(90, 23);
            this.btnSelectFolder.TabIndex = 1;
            this.btnSelectFolder.Text = "Select Folder";
            this.btnSelectFolder.UseVisualStyleBackColor = true;
            this.btnSelectFolder.Click += new System.EventHandler(this.btnSelectFolder_Click);
            // 
            // btnClearAllFolder
            // 
            this.btnClearAllFolder.Location = new System.Drawing.Point(207, 301);
            this.btnClearAllFolder.Name = "btnClearAllFolder";
            this.btnClearAllFolder.Size = new System.Drawing.Size(99, 23);
            this.btnClearAllFolder.TabIndex = 6;
            this.btnClearAllFolder.Text = "Clear All Folder";
            this.btnClearAllFolder.UseVisualStyleBackColor = true;
            this.btnClearAllFolder.Click += new System.EventHandler(this.btnClearAllFolder_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 361);
            this.Controls.Add(this.grpMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "mainForm";
            this.Text = "ClearFile";
            this.grpMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpMain;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnExecute;
        private System.Windows.Forms.Button btnSelectFolder;
        private System.Windows.Forms.ListView lstViewMain;
        private System.Windows.Forms.Button btnUnselectFolder;
        private System.Windows.Forms.Button btnClearAllFolder;
    }
}

